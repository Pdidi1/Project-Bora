<?php
include('config.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Start the session if not already started
}

if(isset($_FILES["image"]["name"])){
    $id=$_POST["id"];
    $nome=$_POST["nome"];

    $imageName=$_FILES["image"]["name"];
    $imageSize=$_FILES["image"]["size"];
    $tmpName=$_FILES["image"]["tmp_name"];

    // Image validation

    $validImageExtension=['jpg', 'jpeg', 'png'];
    $imageExtension=explode('.',$imageName);
    $imageExtension= strtolower(end($imageExtension));
    if(!in_array($imageExtension, $validImageExtension)){
        echo "<script> alert ('Extensão de Imagem Inválida'); </script>";
    } else if($imageSize > 1200000){
        echo "<script> alert ('Imagem muito grande'); </script>";
    } else {
        $newImageName=$nome . "-". date("Y.m.d"). "-" .date("h.i.sa");
        $newImageName.=".". $imageExtension;
        $query="UPDATE  cadastro SET image='$newImageName' WHERE id=$id";
        mysqli_query($connection, $query);
        move_uploaded_file($tmpName, 'imgUser/'. $newImageName);
    }
}

if(isset($_SESSION["id"])){
    $sessionId = $_SESSION["id"];
    $user = mysqli_fetch_assoc(mysqli_query($connection, "SELECT * FROM cadastro WHERE id=$sessionId"));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="dreep.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <form id="form" action="indice.php" method="post" enctype="multipart/form-data"> <!-- Specify the action and method -->
        <div class="upload">
            <?php
            if(isset($user)){
                $id = $user["id"];
                $nome = $user["nome"];
                $image = $user["image"];
            ?>
                <img src="img/<?php echo $image; ?>" width="125" height="125" title="img/<?php echo $image; ?>" alt="">
            <?php } ?>

            <div class="round">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <input type="hidden" name="nome" value="<?php echo $nome; ?>">
                <input type="file" name="image" id="image" accept=".jpg,.jpeg,.png" > 
                <label for="image" class="camera-icon"><i class='bx bxs-camera' style="color:navy "></i></label>
            </div>
        </div>
    </form>

    <script type="text/javascript">
        document.getElementById("image").onchange=function(){
            document.getElementById('form').submit();
        }
    </script>
</body>
</html>
