<?php

$dbUsernmae="root";
$passwaord="";
$dbName="empresa";
$dbHost="localhost";
$connect= new mysqli($dbHost,$dbUsernmae,$passwaord,$dbName);
if($connect->error){
   die("Falha ao conectar ". $connect->error );
} 

?> 