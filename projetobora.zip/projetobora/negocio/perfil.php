<?php

include_once('configN.php');
    


if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET["id"])) {
        echo "ID not provided";
        exit;
    } else {
        $id = $_GET["id"];

        $sql = "SELECT * FROM negocio WHERE id=$id";
        $result = $connect->query($sql);
        $row = $result->fetch_assoc();

        if (!$row) {
            echo "User not found";
            exit;
        } else {
                    
      $nome =$row["nome"];
      $numero= $row["numero"];
      $email= $row["email"];
      $sector= $row["sector"];
      $link= $row["link"];
      $localizacao= $row["localizacao"];
      $provincia= $row["provincia"];
      $image= $row["image"];

        }
    }
} 


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA</title>
    <link rel="stylesheet" href="../drip.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/logo.png">
    <style>
        * {
            padding: 0;
            margin: 0;
        }
        body {
            margin: 0;
            padding: 0;
            background-size: cover;
            background-position: center;
        }

        .navbar {
            width: 100%;
            height: 40px;
            margin: auto;
            padding: 12px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: transparent;
            position: fixed;
            top: 0;
            z-index: 9999; /* Ensure the navbar stays on top */
        }

        .navbar ul {
            list-style: none;
            display: flex;
            align-items: center;
            margin: 0;
            padding: 0;
        }

        .navbar ul li {
            margin: 0 20px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #009688;
            text-transform: uppercase;
        }

        .logo {
            width: 70px;
            cursor: pointer;
        }

        .sub-menu-wrap {
            position: absolute;
            top: 92%;
            right: 0%;
            width: 240px;
            max-height: 0px;
            overflow: hidden;
            transition: max-height 0.5s;
            border-radius: 10px;
        }

        .sub-menu-wrap.open-menu {
            max-height: 400px;
        }

        .sub-menu {
            border-radius: 10px;
            background: navy;
            padding: 20px;
            margin: 10px;
        }

        .sub-menu hr {
            border: 0;
            height: 1px;
            width: 100%;
            background: #009688;
            margin: 15px 0 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            color: #009688;
        }

        .user-info h2 {
            font-weight: 500;
        }

        .icon {
            width: 40px;
            height: 40px;
            margin-right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .icon i {
            font-size: 30px;
        }

        .icons {
            margin-right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 8px;
        }

        .icons i {
            font-size: 23px;
        }

        .sub-menu-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #009688;
            margin: 12px 0;
        }

        .sub-menu-link p {
            width: 100%;
        }

        .sub-menu-link:hover p {
            font-weight: 800;
        }

        /* SLIDES */

        .container {
            position: relative;
            width: 100vw; /* Full width */
            height: 100vh; /* Full height */
        }

        header {
            width: 100%;
            background-color: transparent; /* Background color */
            color: white; /* Text color */
            padding: 50px 0 10px; /* Padding */
            text-align: center; /* Center text */
            z-index: 1; /* Ensure it's above other elements */
        }

        nav {
            position: relative; /* Ensure nav stays relative to header */
        }

        .main{
            padding-top: 40px 10px; /* Adjusted to accommodate the height of the header */
            color: black;
        }
        .main {
            padding: 20px; /* Add padding to create space around the image and text */
            display: grid;
            grid-template-columns: auto 1fr; /* Adjusted to place the image and text next to each other */
            grid-gap: 10px 10px; /* Added gap between image and text */
            align-items: center; /* Center items vertically */
        }


        .main img {
            border-radius: 50%;
            width: 150px;
            height: 150px;
            border: 3px solid #009688;
        }

        h2 {
            color: #009688; /* Adjusted text color */
            margin: 0; /* Removed default margin */
        }

        .text-details {
            display: grid;
            grid-template-rows: repeat(4, auto); /* Adjusted to create 4 rows for the <h4> elements */
            grid-gap: 5px; /* Added gap between <h4> elements */
        }

        .text-details h4 {
            color: #000; /* Adjusted text color */
            margin: 0; /* Removed default margin */
        }
        .link{
            color: lightskyblue;
        }
    </style>
</head>
<body>


<div class="container">
    <header> 
        <div class="navbar">
            <img src="../img/logo.png" class="logo" /> 
            <nav>
                <ul>
                    <li class="icons"><div class="icons"><a href="#" onclick="toggleMenu()"><i class='bx bx-menu'></i></a></div></li>
                </ul>
                <div class="sub-menu-wrap" id="subMenu">
                    <div class="sub-menu">
                       
                        <a href="editN.php?id=<?php echo $id ?>" class="sub-menu-link">
                            <div class="icons"><i class='bx bxs-edit-alt'></i></div>
                            <p>Editar Perfile</p>
                        </a>
                      
                        <a href="#" class="sub-menu-link">
                            <div class="icons"><i class='bx bxs-cog'></i></div>
                            <p>Definições & Ajuda</p>
                        </a>
                        <a href="../logout.php" class="sub-menu-link">
                            <div class="icons"><i class='bx bxs-log-out-circle' ></i></div>
                            <p>Terminar Sessão</p>
                        </a>
                        <a href="deleteN.php?id=<?php echo $id ?>" class="sub-menu-link">
                            <div class="icons"><i class='bx bxs-trash-alt'></i></div>
                            <p>Eliminar Conta</p>
                        </a>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <div class="main">
        <img src="../imgUser/<?php echo $image; ?>" alt="">
        <div class="text-details">
            <h2><?php echo $nome; ?></h2>
            <h4><?php echo $sector; ?></h4>
            <h4><?php echo $numero; ?></h4>
            <h4><?php echo $email; ?></h4>
            <h4><?php echo $localizacao; ?> , <?php echo $provincia; ?> </h4>
            <h4 ><?php echo $link; ?></h4>
    </div>
</div>

<script>
    function toggleMenu(){
        var subMenu = document.getElementById("subMenu");
        subMenu.classList.toggle("open-menu");
    }
</script>

</body>
</html>
