<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA</title>
    <link rel="icon" type="img/png" href="img/logo.png">
    <link href= "https://fonts.googleapis.com/css?family=Kaushan+Script|Popp
ins&display=swap" rel="stylesheet">

</head>
<body>
    <style>
      .navbar{
    width: 85%;
    margin: auto;
    padding: 35px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;

}

.logo{
    width: 120px;
    cursor: pointer;
}


   .content{
    width: 100%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    text-align: center;
    color: navy;
    display: flex;
    justify-content:center;
    align-items: flex-end;
    height: 100vh;
    padding-bottom: 100px;
   
}
.btn{
  width: 200px;
    padding: 15px 0;
    text-align: center;
    margin: 20px 10px ;
    border-radius: 25px;
    font-weight:bolder;
    border: 2px solid  #009688;
    background: transparent;
    color:blue;
    cursor: pointer;
    position: relative;
   
}

.btn span{
    background:  #009688  ;
    height: 100%;
    width: 0;
    border-radius: 25px;
    position: absolute;
    left: 0 ;
    bottom: 0;
    z-index: -1;
    transition: 0.5s;}

button{
    width: 200px;
    padding: 15px 0;
    text-align: center;
    margin: 20px 10px ;
    border-radius: 25px;
    font-weight:bolder;
    border: 2px solid  navy;
    background: transparent;
    color:#009688;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
span{
    background:  blue  ;
    height: 100%;
    width: 0;
    border-radius: 25px;
    position: absolute;
    left: 0 ;
    bottom: 0;
    z-index: -1;
    transition: 0.5s;
}
button:hover span{
    width: 100%;

}
button:hover{
    border: none;
}

      
      .container{
        background-color: rga(0,0,0,0.4) ;
        display: flex;
      }
      .background-clip{
        position: absolute;
        right: 0;
        bottom: 0;
        z-index: -1;
      }
      @media(min-aspect-ratio:16/9){
        .background-clip{
          width: 100%;
          height: auto;
        }
        @media(max-aspect-ratio:16/9){
          .background-clip{
            width:auto;
            height: 100%;
          }
        }

      }
    </style>

   <div class="container"> 
     <video  autoplay loop muted plays-inline class="background-clip">
        <source src="img/beck.mp4" type="video/mp4">
     </video>

    <header>
      
    </header>

    
      <div class="content">
      
           <a href="cadastrar.html">
            <button type="button"><span></span> CADASTRAR</button>
           </a>
           <a href="cadanego.html">
            <button type="button"><span></span> CADASTRAR EMPRESA</button>
           </a>
           <a href="Login.html">
            <button type="button" class="btn"><span></span> LOGIN</button>
         </a>
      </div>
  
   </div>
  
      
   
</body>

</html>