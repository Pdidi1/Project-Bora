<?php
session_start();
$dbUsernmae="root";
$passwaord="";
$dbName="profile";
$dbHost="localhost";
$connection= new mysqli($dbHost,$dbUsernmae,$passwaord,$dbName);
if($connection->error){
   die("Falha ao conectar ". $connection->error );
} 

?> 