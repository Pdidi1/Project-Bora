<?php

include_once('../protecao.php');

if (!isset($_SESSION)) {
    session_start();
    
}
if(isset($_SESSION['id'])){
    include_once('config.php');
    
    $id=$_SESSION['id'];


    $sql = "SELECT * FROM cadastro WHERE id=$id";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        if (!$row) {
            echo "User not found";
            exit;
        } else {
            $image=$row["image"];
        }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bora</title>
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="icon" type="img/png" href="../img/logo.png">
    
</head>
<style> 

        *{
            margin: 0;
            padding: 0;
        }
        html,body{
            margin: 0;
            padding: 0;
        }
        .header {
            min-height: 100vh;
            width: 100%;
            height: 100%;
            background-color: transparent !important; /* Set background color to transparent */
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
            position: relative;
            margin: 0; /* Remove any default margin */
            padding: 0; /* Remove any default padding */
        }
        .text-box{
            width: 90%;
            color:#fff;
            position: absolute;
            top: 50%;
            left: 50%;
            transform:translate(-50%,-50%);
            text-align: center;
        }
        .text-box h1{
            font-size: 62px;
        }
        .text-box p {
            margin:10px 0 40px;
            font-size: 14px;
            color:#fff;
        }

        @media(max-width:700px){
            .text-box h1{
                font-size: 20px;
            }

            .row{flex-direction: column;}
        }

        /* course */

        .course {
            width: 80%;
            margin: auto;
            text-align: center;
            padding-top: 100px;
        }

        .row {
            margin-top: 5%;
            display: flex;
            justify-content: space-between; /* Add space between elements */
            flex-wrap: wrap; /* Allow elements to wrap to the next line */
        }

        .course-col {
            flex-basis: 30%; /* Set a fixed percentage width for all elements */
            width: 250px; /* Ensure each block has the same width */
            background: #e2fee2;
            border-radius: 10px;
            margin-bottom: 5%;
            padding: 20px 12px;
            box-sizing: border-box;
            transition: 0.5s;
        }

        p{
            color: #777;
            font-size: 14px;
            font-weight: 300;
            line-height: 22px;
            padding: 10px;
        }


        h4{
            text-align: center;
            font-weight: 600;
            margin: 10px 0;

        }
        .course-col:hover{
            box-shadow: 0 0 20px 0px rgba(0, 0, 0, 0.2);
        }


        /*campus*/
        .campus {
            width: 80%;
            margin: auto;
            text-align: center;
            padding-top: 50px;
        }

        .campus-col {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            margin-right: 20px; /* Adjust spacing between images */
        }

        .campus-col img {
            width:300px;
            display: block;
        }

        .layer {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%; /* Adjust layer width to cover the entire image */
            height: 100%;
            background-color: rgba(0, 226, 154, 0.701);
            opacity: 0;
            transition: opacity 0.5s;
        }

        .campus-col:hover .layer {
            opacity: 1;
        }
        .layer h3{
            width: 100%;
            font-weight: 500;
            color: #fff;
            font-size: 26px;
            bottom:0;
            left:50% ;
            transform: translateX(-50%);
            position: absolute;
            opacity: 0;
            transition: 0.5s;
        }
        .layer:hover h3{
            bottom:29%;
            opacity: 1;
        }

        /*testimmunial*/
        .testimmunial {
            width: 80%;
            margin: auto;
            text-align: center;
            padding-top: 100px;
        }
        .testimmunial-col{
            flex-basis: 44%;
            border-radius: 10px;
            margin-bottom: 5%;
            text-align: left;
            background: #e2fee2;
            padding: 25px;
            cursor: pointer;
            display: flex;
        }
        .testimmunial-col img{
            height: 60px;
            width: 70px;
            margin-left: 5px;
            margin-right: 30px;
            border-radius: 50%;

        }

        .testimmunial-col p{
            padding: 0;
        }

        .testimmunial-col h3{
            margin-top: 15px;
            text-align: left;
        }

        /*footer*/
        .footer{
            width: 100%;
            text-align: center;
            padding: 30px 0;

        }
        .footer i{
            color: navy;
        }
        .footer h4{
            margin-bottom: 25px;
            margin-top: 20px;
            font-weight: 600;
        }


        /*navbar*/

        .navbar {
            position: absolute; /* Position navbar absolutely */
            top: 0; /* Position navbar at the top of the viewport */
            width: 100%;
            height: 40px;
            margin: auto;
            padding: 12px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: transparent;
            z-index: 9999; /* Ensure the navbar stays on top */
        }

        .navbar ul {
            list-style: none;
            display: flex;
            align-items: center;
            margin: 0;
            padding: 0;
        }
        .navbar ul li {
            margin: 0 20px;
            position: relative; /* Position the list item relatively */
        }

        .navbar ul li a {
            text-decoration: none;
            color: #009688;
            text-transform: uppercase;
        }

        /* Add the underline effect */
        .navbar ul li a:before {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: -3px; /* Position the underline slightly below the text */
            left: 0;
            background-color: #009688;
            visibility: hidden;
            transform: scaleX(0);
            transition: all 0.3s ease-in-out;
        }

        /* Show the underline on hover */
        .navbar ul li a:hover:before {
            visibility: visible;
            transform: scaleX(1);
        }


        .logo {
            width: 80px;
            cursor: pointer;
        }
        /*------barra de pesquisa-------*/
        .search{
            width: 100%;
            height: 25px;
            max-width: 700px;
            background: rgba(255, 255, 255, 0.4);
            border: 2px solid #009688;
            display: flex;
            align-items: center;
            border-radius: 30px;
            padding: 10px 20px;
            backdrop-filter: blur(4px) saturate(180%);
        }
        .search input{
            background: transparent;
            flex: 1;
            border: 0;
            outline: none;
            padding: 5px 10px;
            font-size: 20px;
            color: #cac7ff;
            display: flex;

        }
        .search input::placeholder{
            color: #009688;
        }
        .search button i{
            width:25px;
        }
        .search button {
            color: navy;
            font-size: 20px;
            font-weight: 600;
            border: 0;
            border-radius: 50%;
            width: 35px;
            height: 30px;
            background: #589b75 ;
            cursor: pointer;

        }
      /*-----slies---*/  
        .wrapper {
            position: relative; /* Set the position of the wrapper to relative */
            width: 100vw;
            height: 100vh;
            display: flex;
            overflow: hidden;
        }

        .wrapper-holder {
            display: flex;
            width: 900%;
            animation: slider 23s linear infinite;
        }

        .wrapper-holder > div {
            width: 100vw;
            height: 100vh;
            background-position: center;
            background-size: cover;
            flex-shrink: 0;
        }
            @keyframes slider {
                0% { transform: translateX(0); }
                11.11% { transform: translateX(0); } /* Slide 1 (0% - 100% of 900%) */
                15.43% { transform: translateX(-100vw); } /* Pause after Slide 1 */
                26.54% { transform: translateX(-100vw); } /* Slide 2 (100% - 200% of 900%) */
                30.86% { transform: translateX(-200vw); } /* Pause after Slide 2 */
                42.0% { transform: translateX(-200vw); } /* Slide 3 (200% - 300% of 900%) */
                46.32% { transform: translateX(-300vw); } /* Pause after Slide 3 */
                57.43% { transform: translateX(-300vw); } /* Slide 4 (300% - 400% of 900%) */
                61.75% { transform: translateX(-400vw); } /* Pause after Slide 4 */
                72.86% { transform: translateX(-400vw); } /* Slide 5 (400% - 500% of 900%) */
                77.18% { transform: translateX(-500vw); } /* Pause after Slide 5 */
                88.29% { transform: translateX(-500vw); } /* Slide 6 (500% - 600% of 900%) */
                92.61% { transform: translateX(-600vw); } /* Pause after Slide 6 */
                100% { transform: translateX(-600vw); } /* Ensure the last slide remains visible */
            }

        
        </style>



<body>
    
    <section class="header">
        

        <header> <div class="navbar">
            <img src="../img/logo.png" class="logo" /> 
            <nav>
                <ul>
                    <li class="search"> <input type="search" placeholder="Pesquisar"> <button><i class='bx bx-search-alt'></i></button></li>
                    <li><a href="cadastroN.php" class="lista">Bora para Negocio</a></li>
                    <li class="icons"><div class="icons"><a href="perfilU.php?id=<?php echo $id ?>"><img src="../imgUser/<?php echo $row['image']; ?>"style=" width: 50px;
                        cursor: pointer; border-radius: 50%;  border: 3px solid #009688;" class="logos" /></a></div></li>
                </ul>
            </nav>
        </div>
        

<div class="wrapper">
    <div class="wrapper-holder">
        <div style="background-image: url(../img/fud.jpg);"></div>
        <div style="background-image: url(../img/shopping.jpg);"></div>
        <div style="background-image: url(../img/salo1.jpg);"></div>
        <div style="background-image: url(../img/SPA.jpeg);"></div>
        <div style="background-image: url(../img/tele.jpg);"></div>
        <div style="background-image: url(../img/lava.jpg);"></div>
        <div style="background-image: url(../img/mecha.jpg);"></div>
        <div style="background-image: url(../img/barber.jpg);"></div>
        <div style="background-image: url(../img/ginasio.jpeg);"></div>
    </div>
</div>
</header>

    </section>

    
    <!--------testimunhas---------->

<section class="testimmunial">
    <h1>Reviews</h1>
    <p>Reviews mais recentes da nossa pagina </p>
    <div class="row">
        <div class="testimmunial-col">
            <img src="../img/hotel.jpeg" alt="">
            <div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Non, doloribus aut at consectetur consequuntur ducimus maiores consequatur culpa repellat, incidunt, illo quo temporibus a ex fuga blanditiis ipsum eveniet placeat!</p>
                <h3>joana</h3>
            </div>
        </div>

        <div class="testimmunial-col">
            <img src="../img/gym.jpeg" alt="">
            <div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Non, doloribus aut at consectetur consequuntur ducimus maiores consequatur culpa repellat, incidunt, illo quo temporibus a ex fuga blanditiis ipsum eveniet placeat!</p>
                <h3>isi</h3>
            </div>
        </div>

        
    </div>
</section>

   
    
<!--------campus---------->
<section class="campus">
    <h1>Cidades</h1>
    <p>Nõs estamos expandindo cada vez mais em terretorio nacional. <br> Ja-ja estaremos disponiveis para  todo territorio nacional </p>
    <div class="row">
        <div class="campus-col">
            <img src="../img/Luanda.jpg" alt="">
            <div class="layer">
                <h3>Luanda</h3>
            </div>
        </div>

        <div class="campus-col">
            <img src="../img/Benguela.jpg" alt="">
            <div class="layer">
                <h3>Benguela</h3>
            </div>
        </div>

        <div class="campus-col">
            <img src="../img/Lubango3.jpg" alt="">
            <div class="layer">
                <h3>Huila</h3>
            </div>
        </div>
    </div>
</section>

 
    <!--------course---------->


    <section class="course">
        <h1>Categorias</h1>
        <div class="row">
            <div class="course-col ">
                <h4>Restaurante</h4>
                <p style="color: navy; font-size: 40px;"><i class='bx bx-restaurant'></i> </p>
            </div>

            <div class="course-col ">
                <h4>Beleza & Spa</h4>
                <p style="color: navy; font-size: 40px;"><i class='bx bxs-spa'></i> </p>
            </div>

            <div class="course-col ">
                <h4>Oficinas</h4>
                <p style="color: navy; font-size: 40px;"><i class='bx bxs-car-mechanic'></i> </p>
            </div> <br>

            <div class="course-col ">
                <h4>Hoteis</h4>
                <p style="color: navy; font-size: 40px;"><i class='bx bxs-hotel'></i> </p>
            </div>

            <div class="course-col ">
                <h4>Compras</h4>
                <p style="color: navy; font-size: 40px;"><i class='bx bxs-shopping-bags'></i> </p>
            </div>

            
            <div class="course-col ">
                <h4>Mais</h4>
                <p style="color: navy; font-size: 40px;"><i class='bx bx-dots-horizontal-rounded'></i> </p>
            </div>

        </div>
    </section>







<!--------footer---------->

<section class="footer">
   <h4>Sobre Nós </h4>
   
    <p> BORA é um aplicativo directorio para empresas poderam se conectar com potenciais clientes. <br>
        Criando assim uma comunidade para  empresas e clientes ajudando clientes a conhecer novos horizontes.  </p>

        <div class="icons">
            <i class='bx bxl-facebook-square'></i>
            <i class='bx bxl-instagram-alt'></i>
            <i class='bx bxl-linkedin-square'></i>
        </div>

        <p> Feito com <i class='bx bx-heart'></i> por Tchipoque </p>
</section>


</body>
</html>