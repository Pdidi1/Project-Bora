<?php

include('config.php');

if(isset($_POST["submit"])){

    $nome=$_POST["nome"];
    $username=$_POST["username"];
    $email=$_POST["email"];
    $genero=$_POST["genero"];
    $nascimento=$_POST["nascimento"];
    $numero=$_POST["numero"];
    $senha=$_POST["senha"];
    $confirm=$_POST["confirm"];

    $duplicate = mysqli_query($conn,"SELECT * FROM cadastro WHERE username='$username' ");
     
    if(mysqli_num_rows($duplicate)>0){
        echo "<script> alert ('Username já está em uso'); </script>";
    } else{
        //calcular nascimento
        $data_nas= new DateTime($nascimento); 
        $hoje= new DateTime();
        $idade= $hoje->diff($data_nas)->y;

        if ($data_nas > $hoje) {
            echo "<script> alert('Data de nascimento inválida. Por favor, insira uma data de nascimento válida.'); </script>";
        }else if($idade>=16){
            if($senha== $confirm){
                // Upload and register image
                $image = 'user.png'; // Default image
                if(isset($_FILES["image"]["name"]) && $_FILES["image"]["name"] != ""){
                    $imageName = $_FILES["image"]["name"];
                    $imageSize = $_FILES["image"]["size"];
                    $tmpName = $_FILES["image"]["tmp_name"];
              
                    // Image validation
                    $validImageExtension = ['jpg', 'jpeg', 'png'];
                    $imageExtension = explode('.', $imageName);
                    $imageExtension = strtolower(end($imageExtension));
                    if(!in_array($imageExtension, $validImageExtension)){
                        echo "<script> alert ('Extensão de Imagem Inválida'); </script>";
                    } else if($imageSize > 1200000){
                        echo "<script> alert ('Imagem muito grande'); </script>";
                    } else {
                        $image = $username . "_" . date("Y.m.d") . "-" . date("h.i.sa") . "." . $imageExtension;
                        move_uploaded_file($tmpName, '../img/' . $image);
                    }
                }
                
                // Insert user data into database
                $query = mysqli_query($conn, "INSERT INTO cadastro (nome, username, email, genero, nascimento, numero, senha, image)
                VALUES ('$nome', '$username', '$email', '$genero', '$nascimento', '$numero', '$senha', '$image')");

                if($query){
                    echo "<script> alert ('Cadastro feito com sucesso'); </script>";
                    header("Location: ../login.php");
                } else {
                    echo "<script> alert ('Erro ao cadastrar'); </script>";
                }
            } else {
                echo "<script> alert ('Senhas não coincidem'); </script>";
            }
        } else {
            echo "<script> alert ('Deves ter pelo menos 16 anos para cadastrar'); </script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA-Cadastro</title>
    <link rel="stylesheet" href="../drip.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/logo.png">
</head>
<body>
    <style>
        body {
            background-image:  url(../img/wall.jpg);
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
            background-blend-mode: darken;
        }

        .upload {
            width: 125px;
            position: relative;
            margin: auto;
        }

        .upload img {
            border-radius: 50%;
            border: 3px solid #009688;
        }

        .upload .round {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            border-radius: 50%;
            overflow: hidden;
            background-color: black; /* Add black background */
        }

        .upload .round input[type=file] {
            position: absolute;
            transform: scale(3);
            opacity: 0;
        }

        .camera-icon {
            position: absolute;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            color: white; /* Set icon color to white */
        }

    </style>

    <div class="con">
        <div class="wrapper">
            <form id="form" action="cadastrar.php" method="post" enctype="multipart/form-data"> 
                <h1>CADASTRO</h1>

                <div class="upload">
                    <?php
                    if(isset($user)){
                        $id = $user["id"];
                        $nome = $user["nome"];
                        $image = $user["image"];
                    ?>
                        <img id="profile-image" src="../imgUser/<?php echo $image; ?>" width="125" height="125" title="<?php echo $image; ?>" alt="">
                    <?php } else { ?>
                        <img id="profile-image" src="../imgUser/user.png" width="125" height="125" title="user.png" alt="">
                    <?php } ?>

                    <div class="round">
                        <input type="file" name="image" id="image" accept=".jpg,.jpeg,.png">
                        <label for="image" class="camera-icon"><i class='bx bxs-camera' style="color:navy "></i></label>
                    </div>
                </div>

                <div class="input-box">
                    <input type="text" name="nome" id="nome" placeholder="NOME" required value=""><br>
                </div>
             <div class="input-box">
               <input type="text" name="username" id="username" placeholder="USERNAME"  required value=""><br>
             </div>
             <div class="input-box">
               <input type="email" name="email" id="email" placeholder="E-MAIL" required value=""><br>
             </div>
             <div class="input-box">
                
                <div class="select-container">
                  <select class="select-box" name="genero" required>
                    <option value="">Genero</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                </select>
                <div class="icon-container">
                  <i class='bx bx-caret-down'></i>
                </div>
                </div>
              </div>
              <div class="input-box">
                <label for="data">Data de nascimento</label>
                <input type="date" name="nascimento" id="nascimento" required value=""><br>
              </div>
              <div class="input-box">
              <input type="tel" name="numero" id="numero" placeholder="NUMERO DE TELEFONE" value="" required><br>
            </div>
             <div class="input-box">
               <input type="password" name="senha" id="senha" placeholder="SENHA" required value=""><br>
             </div>
             <div class="input-box">
               <input type="password" name="confirm" id="confirm" placeholder="CONFIRMA A SENHA" required value=""><br>
             </div>
 

                <div class="register-link"><p>
                    <button type="submit" class="btn" name="submit"> <span></span> CADASTRAR</button><br>
                    Quer criar conta Empresarial? <a href="../negocio/cadastroN.php">Cadastrar Negocio</a> <br> 
                    Já tem conta?<a href="../login.php"> Login</a> 
                </p></div>
            </form>
        </div>
    </div>
    

    <script>
        document.getElementById("image").addEventListener("change", function() {
            var fileInput = this;
            var fileReader = new FileReader();
            
            fileReader.onload = function() {
                var profileImage = document.getElementById("profile-image");
                profileImage.src = fileReader.result;
            }
            
            fileReader.readAsDataURL(fileInput.files[0]);
        });
    </script>
</body>
</html>
