<?php

$dbUsernmae="root";
$passwaord="";
$dbName="pessoal";
$dbHost="localhost";
$conn= new mysqli($dbHost,$dbUsernmae,$passwaord,$dbName);
if($conn->error){
   die("Falha ao conectar ". $conn->error );
} 

?>