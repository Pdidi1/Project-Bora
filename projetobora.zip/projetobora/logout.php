<?php
if (!isset($_SESSION)) {
    session_start();
}
session_destroy();
    $_SESSION['id']=$cadastro['id'];
    $_SESSION['nome']=$cadastro['nome'];
    $_SESSION['id']=$negocio['id'];
    $_SESSION['nome']=$negocio['nome'];
header("Location:../login.php");
?>