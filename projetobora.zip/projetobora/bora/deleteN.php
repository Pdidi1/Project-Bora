<?php
if (!empty($_GET['id'])) {
    include_once('configN.php');
    $id = $_GET['id'];
    $sqlSelect = "SELECT * FROM negocio WHERE id='$id'";
    $result = $connect->query($sqlSelect);

    if ($result->num_rows > 0) {
        $sqlDelete = "DELETE FROM negocio WHERE id='$id'";
        $resultDelete = $connect->query($sqlDelete);
    }
}
header('Location: registros.php');
?>
