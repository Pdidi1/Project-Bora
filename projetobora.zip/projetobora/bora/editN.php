<?php
include_once('configN.php');

$id = "";
$nome = "";
$numero= "";
$email= "";
$sector= "";
$link= "";
$localizacao= "";
$provincia= "";
$senha= "";
       


if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET["id"])) {
        echo "ID not provided";
        exit;
    } else {
        $id = $_GET["id"];

        $sql = "SELECT * FROM negocio WHERE id=$id";
        $result = $connect->query($sql);
        $row = $result->fetch_assoc();

        if (!$row) {
            echo "User not found";
            exit;
        } else {
                    
      $nome =$row["nome"];
      $numero= $row["numero"];
      $email= $row["email"];
      $sector= $row["sector"];
      $link= $row["link"];
      $localizacao= $row["localizacao"];
      $provincia= $row["provincia"];
      $senha= $row["senha"];

        }
    }
} else {
        $id = $_POST["id"];
        $nome=$_POST["nome"];
        $numero=$_POST["numero"];
        $email=$_POST["email"];
        $sector=$_POST["sector"];
        $link=$_POST["link"];
        $localizacao=$_POST["localizacao"];
        $provincia=$_POST["provincia"];
        $senha=$_POST["senha"];

    if (empty($id) || empty($nome) || empty($numero) || empty($email) || empty($sector) || empty($localizacao) || empty($provincia)|| empty($senha)) {
        echo "<script> alert ('Preencha todos os campos'); </script>";
    } else {
        $sql = "UPDATE negocio SET nome='$nome', numero='$numero' , email='$email' , sector='$sector', link='$link',localizacao='$localizacao',provincia='$provincia', senha='$senha' WHERE id=$id";
        $result = $connect->query($sql);

                    
        // Check if image file is selected
        if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0){
          $targetDir = "../imgUser/";
          $imageName = basename($_FILES["image"]["name"]);
          $targetFilePath = $targetDir . $imageName;
          $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
          
          // Check if file is a valid image
          $validExtensions = array("jpg", "jpeg", "png", "gif");
          if(in_array($fileType, $validExtensions)){
              // Upload file to server
              if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
                  // Update image path in the database
                  $sql = "UPDATE negocio SET  image='$imageName' WHERE id=$id";
                  $result = $connect->query($sql);

                  if (!$result) {
                      echo "<script> alert ('Query inválido: ".$connect->error."'); </script>";
                  } else {
                      echo "<script> alert ('Atualização feita com sucesso'); </script>";
                      header("Location: perfil.php");
                      exit;
                  }
              } else {
                  echo "<script> alert ('Falha ao enviar o arquivo.'); </script>";
              }
          } else {
              echo "<script> alert ('Apenas JPG, JPEG, PNG e GIF são permitidos.'); </script>";
          }   

      } else {
          echo "<script> alert ('Por favor, selecione um arquivo de imagem.'); </script>";
      }


        if (!$result) {
            echo "<script> alert ('Query invalido: .$connect->error'); </script>";
        } else {
            echo "<script> alert ('Atualização feita com successo'); </script>";
            header("Location: perfil.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA-Editar</title>
    <link rel="stylesheet" href="../drip.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/logo.png">
</head>
<body> 
  <style>
        body{
        
        background-image:  url(./img/wall.jpg);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: 100% 100%;
        background-blend-mode: darken;
      
        }
    
        .upload {
            width: 125px;
            position: relative;
            margin: auto;
        }
        .upload img {
            border-radius: 50%;
            border: 3px solid #009688;
        }
        .upload .round {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            border-radius: 50%;
            overflow: hidden;
            background-color: black; /* Add black background */
        }
        .upload .round input[type=file] {
            position: absolute;
            transform: scale(3);
            opacity: 0;
        }
        .camera-icon {
            position: absolute;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            color: white; /* Set icon color to white */
        }
  </style>


    <div class="con">
        <div class="wrapper">
        <form action="editN.php" method="POST" enctype="multipart/form-data">

             <h1>CADASTRO DE EMPRESA</h1>

             <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="upload">
                    <img id="previewImage" src="../imgUser/<?php echo $row['image']; ?>" width="125" height="125" alt="Preview Image">
                    <div class="round">
                        <input type="file" name="image" id="image" accept=".jpg,.jpeg,.png" onchange="previewFile()"> 
                        <label for="image" class="camera-icon"><i class='bx bxs-camera' style="color:navy "></i></label>
                    </div>
                </div>
             <div class="input-box">
               <input type="text" name="nome" id="nome"  placeholder="NOME DE EMPRESA" value="<?php echo $nome; ?>" required><br>
             </div>
   

             <div class="input-box">
              <input type="tel" name="numero" id="numero" placeholder="NUMERO DE TELEFONE" value="<?php echo $numero; ?>" required><br>
            </div>
            <div class="input-box">
              <input type="email" name="email" id="email" placeholder="E-MAIL" value="<?php echo $email; ?>" required><br>
            </div>
            
             <div class="input-box">
               <input type="url" name="link" id="link" placeholder="LINK(OPCIONAL)" value="<?php echo $link; ?>"><br>
             </div>
             
             <div class="input-box">
                
                <div class="select-container">
                  <select name="sector" class="select-box" required>
                  <option value="<?php echo $sector; ?>" selected><?php echo $sector; ?></option>
                    <option value="Bares">Bares</option>
                    <option value="Barbearia">Barbearia</option>
                    <option value="Comidas rapidas">Comidas rapidas</option>
                    <option value="Compars\lojas">Compras\lojas</option>
                    <option value="Discotecas">Discotecas</option>
                    <option value="Estação de serviço">Estação de serviço</option>
                    <option value="Ginásio">Ginásio</option>
                    <option value="Hotel">Hotel</option>
                    <option value="Lavandaria">Lavandaria</option>
                    <option value="Oficina">Oficina</option>
                    <option value="Reparação de Telemoveis">Reparação de Telemoveis</option>
                    <option value="Restaurante">Restaurante</option>
                    <option value="Salão">Salão de beleza</option>
                    <option value="Spa">Spa</option>
                    <option value="Outro">Outro</option>
                    
                  </select>
                <div class="icon-container">
                  <i class='bx bx-caret-down'></i>
                </div>
                </div>
              </div>



              <div class="input-box">
               <input type="text" name="localizacao" id="localizacao" placeholder="LOCALIZAÇÃO" value="<?php echo $localizacao; ?>"><br>
             </div> 
             
             <div class="input-box">
                
                <div class="select-container">
                  <select name="provincia" class="select-box" required>
                  <option value="<?php echo $provincia; ?>" selected><?php echo $provincia; ?></option>
                    <option value="Luanda">Luanda</option>
                    <option value="Benguela">Benguela</option>
                    <option value="Lubango">Lubango</option>
                    
                  </select>
                <div class="icon-container">
                  <i class='bx bx-caret-down'></i>
                </div>
                </div>
              </div>
              
             <div class="input-box">
               <input type="password" name="senha" id="senha" placeholder="SENHA" required value="<?php echo $senha; ?>"><br>
             </div>
            

            
             <div class="register-link"><p>
               <button type="submit" class="btn" name="submit"> <span></span> ATUALIZAR</button><br>
             </div>
           </form>
        </div>
    </div>
   


    
    <script>
        function previewFile() {
            const preview = document.getElementById('previewImage');
            const file = document.getElementById('image').files[0];
            const reader = new FileReader();

            reader.onloadend = function () {
                preview.src = reader.result;
            }

            if (file) {
                reader.readAsDataURL(file);
            } else {
                preview.src = "imgUser/<?php echo $row['image']; ?>";
            }
        }
    </script>

</body>
</html>
