<?php
include_once('../usuario/config.php');
include_once('../negocio/configN.php');

$search = '';

if(isset($_GET['pesquisar'])) {
    $search = $_GET['pesquisar'];
    $sql = "SELECT * FROM cadastro WHERE nome LIKE '%$search%' or username LIKE '%$search%' or  email LIKE '%$search%' or  numero LIKE '%$search%'";
    $sqln = "SELECT * FROM negocio WHERE nome LIKE '%$search%' or sector LIKE '%$search%' or  email LIKE '%$search%' or  numero LIKE '%$search%' or  link LIKE '%$search%' or  localizacao LIKE '%$search%' or  provincia LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM cadastro ORDER BY nome DESC";
    $sqln = "SELECT * FROM negocio ORDER BY nome DESC";
}

$result = $conn->query($sql);
$resultn = $connect->query($sqln);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA-Cadastros</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/logo.png">
</head>

<style>
        body {
            background-image: url(./img/wall.jpg);
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
            background-blend-mode: darken;
        }

        .table {
            width: 80%; /* Make the table fill its container */
            border-collapse: collapse;
            margin: 25px 10px;
            font-size: 0.9em;
            min-width: 400px;
            background-color: transparent;
            border: 2px solid rgba(224, 255, 255, 0.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(224, 255, 255, 0.2);
            padding: 30px 40px;
            border-radius: 5px 5px 0 0;
            overflow: hidden;
        }
        .table-cont{
            text-align: center;
            margin: auto;
            
        }
        .tables {
            width: 550px; /* Make the table fill its container */
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            min-width: 400px;
            background-color: transparent;
            border: 2px solid rgba(224, 255, 255, 0.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(224, 255, 255, 0.2);
            padding: 30px 40px;
            border-radius: 5px 5px 0 0;
            overflow: hidden;
        }

        .table thead tr {
            color: navy;
            font-weight: bolder;
            text-align: left;
            background-color: #009688;
        }
        .tables thead tr {
            color: #009688;
            font-weight: bolder;
            text-align: left;
            background-color: navy;
        }

        .table th {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
            
        }

        .tables th {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
            
        }

        .table td {
            padding: 5px 20px;
            vertical-align: middle;
            text-align: center;
            color: #009688;
        }
        .tables td {
            padding: 5px 20px;
            vertical-align: middle;
            text-align: center;
            color: #009688;
        }

        .mb {
            text-align: center;
            margin: auto;
            width: 80%; /* Adjust the width as needed */
        }
        .mbs {
            display: flex;
            justify-content: center;
            align-items: center; /* Center vertically */
            text-align: center;
            margin: auto;
            width: 80%;
            }

        .mb h2 {
            color: white;
            font-weight: bold;
        }

        .con {
            justify-content: center;
            display: flex;
            text-align: center;
             margin: auto;
        }
        .cons {
            justify-content: center;
            display: flex;
        }

        .btn-primary, .btn-danger {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
        }

        .btn-primary {
            color:navy;
            font-size:25px;
        }

        .btn-danger {
            color: #f44336;
            font-size: 20px;
        }



        .hr-row td {
            padding: 5px 20px; /* Reset padding for these rows */
            font-weight: bolder;
        }

        .hr-row hr {
            margin: 0; /* Remove margin of hr */
            border: none; /* Remove border of hr */
            border-top: 1px solid rgba(224, 224, 224, 0.5); /* Add border top */
            width: 100%; /* Ensure hr spans the entire row */
            font-weight: bolder;
        }

        /* Modify hover effect to exclude hr rows */
        .table tbody tr:hover:not(.hr-row) {
            background-color: #e2fee2;
            transition: 0.3s ease;
        }


        .table .btn-group {
            display: flex;
            align-items: center;
        }



        .table .btn-group a i {
             vertical-align: middle;
        }
        .table img {
            border-radius: 50%;
            border: 2px solid #009688;
        }
            /* barra de pesquisa */

        .search {
            width: 80%; /* Adjust width as needed */
            max-width: 400px; /* Set maximum width */
            height: 45px; /* Adjust height as needed */
            background: rgba(255, 255, 255, 0.2);
            display: flex; /* Change display to flex */
            align-items: center;
            justify-content: space-between; /* Distribute space between items */
            border-radius: 30px;
            backdrop-filter: blur(4px) saturate(180%);
            margin: auto; /* Center horizontally */
            padding: 0 10px; /* Add padding to create space */
        }

        .search input {
            background: transparent;
            border: 0;
            outline: none;
            padding: 5px; /* Adjust padding as needed */
            font-size: 20px;
            color: #cac7ff;
            flex: 1; /* Grow input to fill available space */
            margin-right: 10px; /* Add margin to separate from button */
        }

        .search input::placeholder {
            color: #009688;
        }

        .search button {
            color: navy;
            font-size: 25px;
            font-weight: 600;
            border: 0;
            border-radius: 50%;
            /* Adjust margin to move the button closer to the left */
            margin-left: 92.5px;
            width: 40px;
            height: 100%;
            background: #589b75;
            cursor: pointer;
            padding: 5px;
        }


        .search button i{
            width:25px;
        }


</style>


<body>

<div class="search">
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
        <input type="search" class="form-control" placeholder="Pesquisar" id="pesquisar" name="pesquisar" value="<?php echo $search; ?>">
        <button type="submit" ><i class='bx bx-search-alt'></i></button>
    </form>
</div>


<?php
include_once('../usuario/config.php');
include_once('../negocio/configN.php');

// Count of Contas Pessoais
$sql_count_pessoais = "SELECT COUNT(*) AS count_pessoais FROM cadastro";
$result_count_pessoais = $conn->query($sql_count_pessoais);
$count_pessoais = $result_count_pessoais->fetch_assoc()['count_pessoais'];

// Count of Contas Empresariais
$sql_count_empresariais = "SELECT COUNT(*) AS count_empresariais FROM negocio";
$result_count_empresariais = $connect->query($sql_count_empresariais);
$count_empresariais = $result_count_empresariais->fetch_assoc()['count_empresariais'];
?>

<div class="cons">
        <div class="mbs">
            <table class="tables ">
           <thead>
                <tr>
                    <th>Numero de Contas Pessoais:</th>
                    <th>Numero de Contas Empresariais:</th>
                </tr>
            </thead>
            <tbody>
                
                <?php
                echo "<tr>";
                echo "<td>" .$count_pessoais . "</td>";
                echo "<td>" . $count_empresariais . "</td>";
                echo "</tr>";
                ?>
            </tbody>
           </table>
        </div>
    </div>

<div class="con">
    <div class="mb">
        <table class="table">
            <h2><u>Contas Pessoais</u></h2>
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">PERFIL</th>
                <th scope="col">NOME</th>
                <th scope="col">USERNAME</th>
                <th scope="col">E-MAIL</th>
                <th scope="col">GENERO</th>
                <th scope="col">DATA DE NASCIMENTO</th>
                <th scope="col">NUMERO DE TELEMOVEIS</th>
                <th scope="col">SENHA</th>
                <th scope="col">...</th>
            </tr>
            </thead>
            <tbody>
            <?php
            while ($user_data = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $user_data['id'] . "</td>";?>
               <td> <img src="../imgUser/<?php echo $user_data['image']; ?>" width="50" height="50" alt=""></td>;<?php
                echo "<td>" . $user_data['nome'] . "</td>";
                echo "<td>" . $user_data['username'] . "</td>";
                echo "<td>" . $user_data['email'] . "</td>";
                echo "<td>" . $user_data['genero'] . "</td>";
                echo "<td>" . $user_data['nascimento'] . "</td>";
                echo "<td>" . $user_data['numero'] . "</td>";
                echo "<td>" . $user_data['senha'] . "</td>";
                echo "<td>
                <div class='btn-group'>
                    <a class='btn-primary' href='edit.php?id=" . $user_data['id'] . "'><i class='bx bxs-edit'></i></a> 
                    <a class='btn-danger' href='delete.php?id=" . $user_data['id'] . "'><i class='bx bxs-trash-alt'></i></a>
                </div>
              </td>";
        
                echo "</tr>";
                echo "<tr class='hr-row'><td colspan='10'><hr></td></tr>"; // Add hr-row class here

            }
            ?>
            </tbody>
        </table>
        
        <div class="table-cont">
            
        <table class="table">
            <h2><u>Contas Empresariais</u></h2>
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">PERFIL</th>
                <th scope="col">NOME</th>
                <th scope="col">TELEFONE</th>
                <th scope="col">E-MAIL</th>
                <th scope="col">SECTOR</th>
                <th scope="col">SITE</th>
                <th scope="col">LOCALIZAÇÃO</th>
                <th scope="col">PROVINCIA</th>
                <th scope="col">SENHA</th>
                <th scope="col">...</th>
            </tr>
            </thead>
            <tbody>
            <?php
            while ($usern_data = mysqli_fetch_assoc($resultn)) {
                echo "<tr>";
                echo "<td>" . $usern_data['id'] . "</td>";?>
                <td> <img src="../imgUser/<?php echo $usern_data['image']; ?>" width="50" height="50" alt=""></td>;<?php
                echo "<td>" . $usern_data['nome'] . "</td>";
                echo "<td>" . $usern_data['numero'] . "</td>";
                echo "<td>" . $usern_data['email'] . "</td>";
                echo "<td>" . $usern_data['sector'] . "</td>";
                echo "<td>" . $usern_data['link'] . "</td>";
                echo "<td>" . $usern_data['localizacao'] . "</td>";
                echo "<td>" . $usern_data['provincia'] . "</td>";
                echo "<td>" . $usern_data['senha'] . "</td>";
                echo "<td>
        <div class='btn-group'>
            <a class='btn-primary' href='editN.php?id=" . $usern_data['id'] . "'><i class='bx bxs-edit'></i></a> 
            <a class='btn-danger' href='deleteN.php?id=" . $usern_data['id'] . "'><i class='bx bxs-trash-alt'></i></a>
        </div>
      </td>";

                echo "</tr>";
                echo "<tr class='hr-row'><td colspan='11'><hr></td></tr>"; // Add hr-row class here

            }
            ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
</body>
</html>
