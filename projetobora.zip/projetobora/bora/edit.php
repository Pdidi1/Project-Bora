<?php
include_once('config.php');

$id = "";
$nome = "";
$username = "";
$email = "";
$nascimento = "";
$genero = "";
$senha = "";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET["id"])) {
        echo "ID not provided";
        exit;
    } else {
        $id = $_GET["id"];

        $sql = "SELECT * FROM cadastro WHERE id=$id";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        if (!$row) {
            echo "User not found";
            exit;
        } else {
            $nome = $row["nome"];
            $username = $row["username"];
            $email = $row["email"];
            $nascimento = $row["nascimento"];
            $genero = $row["genero"];
            $senha = $row["senha"];
        }
    }
} else {
    $id = $_POST["id"];
    $nome = $_POST["nome"];
    $username = $_POST["username"];
    $email = $_POST["email"];
    $genero = $_POST["genero"];
    $nascimento = $_POST["nascimento"];
    $senha = $_POST["senha"];

    if (empty($id) || empty($nome) || empty($username) || empty($email) || empty($genero) || empty($nascimento) || empty($senha)) {
        echo "<script> alert ('Preencha todos os campos'); </script>";
    } else {

        $sql = "UPDATE cadastro SET nome='$nome', username='$username', email='$email', genero='$genero', nascimento='$nascimento', senha='$senha'  WHERE id=$id";
                    $result = $conn->query($sql);
                    
        // Check if image file is selected
        if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0){
            $targetDir = "imgUser/";
            $imageName = basename($_FILES["image"]["name"]);
            $targetFilePath = $targetDir . $imageName;
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
            
            // Check if file is a valid image
            $validExtensions = array("jpg", "jpeg", "png", "gif");
            if(in_array($fileType, $validExtensions)){
                // Upload file to server
                if(move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)){
                    // Update image path in the database
                    $sql = "UPDATE cadastro SET  image='$imageName' WHERE id=$id";
                    $result = $conn->query($sql);

                    if (!$result) {
                        echo "<script> alert ('Query inválido: ".$conn->error."'); </script>";
                    } else {
                        echo "<script> alert ('Atualização feita com sucesso'); </script>";
                        header("Location: perfilU.php");
                        exit;
                    }
                } else {
                    echo "<script> alert ('Falha ao enviar o arquivo.'); </script>";
                }
            } else {
                echo "<script> alert ('Apenas JPG, JPEG, PNG e GIF são permitidos.'); </script>";
            }   

        } else {
            echo "<script> alert ('Por favor, selecione um arquivo de imagem.'); </script>";
        }


        if (!$result) {
            echo "<script> alert ('Query inválido: ".$conn->error."'); </script>";
        } else {
            echo "<script> alert ('Atualização feita com sucesso'); </script>";
            header("Location: perfilU.php");
            exit;
        }

    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA-Editar</title>
    <link rel="stylesheet" href="../drip.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/logo.png">
</head>
<body>
    <style>
        body {
            background-image: url(./img/wall.jpg);
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
            background-blend-mode: darken;
        }
        .upload {
            width: 125px;
            position: relative;
            margin: auto;
        }
        .upload img {
            border-radius: 50%;
            border: 3px solid #009688;
        }
        .upload .round {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            border-radius: 50%;
            overflow: hidden;
            background-color: black; /* Add black background */
        }
        .upload .round input[type=file] {
            position: absolute;
            transform: scale(3);
            opacity: 0;
        }
        .camera-icon {
            position: absolute;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            color: white; /* Set icon color to white */
        }
    </style>

    <div class="con">
        <div class="wrapper">
            <form id="editForm" action="edit.php" method="POST" enctype="multipart/form-data">
                <h1>CADASTRO</h1>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="upload">
                    <img id="previewImage" src="../imgUser/<?php echo $row['image']; ?>" width="125" height="125" alt="Preview Image">
                    <div class="round">
                        <input type="file" name="image" id="image" accept=".jpg,.jpeg,.png" onchange="previewFile()"> 
                        <label for="image" class="camera-icon"><i class='bx bxs-camera' style="color:navy "></i></label>
                    </div>
                </div>
                <div class="input-box">
                    <input type="text" name="nome" id="nome" placeholder="NOME" required value="<?php echo $nome; ?>"><br>
                </div>      
                <div class="input-box">
                    <input type="text" name="username" id="username" placeholder="USERNAME"  required value="<?php echo $username; ?>"><br>
                </div>
                <div class="input-box">
                    <input type="email" name="email" id="email" placeholder="E-MAIL" required value="<?php echo $email; ?>"><br>
                </div>
                <div class="input-box">
                    <div class="select-container">
                        <select class="select-box" name="genero" required>
                            <option value="<?php echo $genero; ?>" selected><?php echo $genero; ?></option>
                            <option value="Masculino">Masculino</option>
                            <option value="Femenino">Femenino</option>
                        </select>
                        <div class="icon-container">
                            <i class='bx bx-caret-down'></i>
                        </div>
                    </div>
                </div>
                <div class="input-box">
                    <label for="data">Data de nascimento</label>
                    <input type="date" name="nascimento" id="nascimento" required value="<?php echo $nascimento; ?>"><br>
                </div>
                <div class="input-box">
                    <input type="password" name="senha" id="senha" placeholder="SENHA" required value="<?php echo $senha; ?>"><br>
                </div>
                <div class="register-link">
                    <p>
                        <button type="submit" class="btn" name="submit"> <span></span> ATUALIZAR</button><br>
                    </p>
                </div>
            </form>
        </div>
    </div>
   

    <script>
        function previewFile() {
            const preview = document.getElementById('previewImage');
            const file = document.getElementById('image').files[0];
            const reader = new FileReader();

            reader.onloadend = function () {
                preview.src = reader.result;
            }

            if (file) {
                reader.readAsDataURL(file);
            } else {
                preview.src = "imgUser/<?php echo $row['image']; ?>";
            }
        }
    </script>
</body>
</html>
