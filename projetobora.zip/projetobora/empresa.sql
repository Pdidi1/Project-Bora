-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2024 at 03:44 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `empresa`
--

-- --------------------------------------------------------

--
-- Table structure for table `negocio`
--

CREATE TABLE `negocio` (
  `id` int(11) NOT NULL,
  `image` varchar(5000) NOT NULL,
  `nome` varchar(500) NOT NULL,
  `numero` varchar(50) NOT NULL,
  `email` varchar(500) NOT NULL,
  `sector` varchar(500) NOT NULL,
  `link` varchar(800) NOT NULL,
  `localizacao` varchar(500) NOT NULL,
  `provincia` varchar(500) NOT NULL,
  `senha` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `negocio`
--

INSERT INTO `negocio` (`id`, `image`, `nome`, `numero`, `email`, `sector`, `link`, `localizacao`, `provincia`, `senha`) VALUES
(1, 'bisno.jpg', 'Bora', '927661149', 'boraa@bora.com', 'Outro', '', 'Mupas,Benfica', 'Luanda', 'bora'),
(2, 'bisno.jpg', 'Catumbela&filhos', '927661149', 'catumbela@gmail.com', 'Outro', '', 'Morro bento', 'Benguela', 'catumbela');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `negocio`
--
ALTER TABLE `negocio`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `negocio`
--
ALTER TABLE `negocio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
