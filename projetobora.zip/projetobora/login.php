<?php
if (isset($_POST["submit"])) {
    include_once('usuario/config.php');
    include_once('negocio/configN.php');
   
    // Pessoal
    $nome = $conn->real_escape_string($_POST['nome']);
    $senha = $conn->real_escape_string($_POST['senha']);

    $sql_code = "SELECT * FROM cadastro WHERE username='$nome' AND senha='$senha'";
    $sql_query = $conn->query($sql_code) or die("Falha na execucao do codigo SQL: " . $conn->error);
    $quantidade = $sql_query->num_rows;

    // Empresarial
    $nome = $connect->real_escape_string($_POST['nome']);
    $senha = $connect->real_escape_string($_POST['senha']);

    $sql_cobe = "SELECT * FROM negocio WHERE nome='$nome' AND senha='$senha'";
    $sql_que = $connect->query($sql_cobe) or die("Falha na execucao do codigo SQL: " . $connect->error);
    $quan = $sql_que->num_rows;
    
    $alert = '';
    if ($quantidade == 1) {
        $cadastro = $sql_query->fetch_assoc();
        if (!isset($_SESSION)) {
            session_start();
        }
        $_SESSION['id'] = $cadastro['id'];
        $_SESSION['nome'] = $cadastro['nome'];
        header("Location:usuario/home.php");
        exit();
    } elseif ($quan == 1) {
        $negocio = $sql_que->fetch_assoc();
        if (!isset($_SESSION)) {
            session_start();
        }
        $_SESSION['id'] = $negocio['id'];
        $_SESSION['nome'] = $negocio['nome'];
        if ($_SESSION['nome'] == 'Bora') {
            header("Location:bora/homeB.php");
        } else {
            header("Location:negocio/homeN.php");
        }
        exit();
    } else {
        $alert = '
        <svg xmlns="http://www.w3.org/2000/svg" class="d-none">
          <symbol id="exclamation-triangle-fill" viewBox="0 0 16 16">
              <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
          </symbol>
        </svg>
        <div class="alert alert-warning alert-dismissible fade show d-flex align-items-center custom-alert" role="alert">
            <svg class="bi flex-shrink-0 me-2" role="img" aria-label="Warning:"><use xlink:href="#exclamation-triangle-fill"/></svg>
            <div>
                Falha ao logar! Nome ou Senha incorrecta.
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BORA-Login</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/logo.png">
    <style>
        body {
            background-image: url(img/wall.jpg);
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            background-blend-mode: darken;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .navbar {
            width: 85%;
            margin: auto;
            padding: 35px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: navy;
        }

        .logo {
            width: 120px;
            cursor: pointer;
        }

        .content {
            width: 100%;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            text-align: center;
            color: navy;
        }

        button {
            width: 200px;
            padding: 15px 0;
            text-align: center;
            margin: 20px 10px;
            border-radius: 25px;
            font-weight: bold;
            border: 2px solid #009688;
            background: transparent;
            color: navy;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        span {
            background: #009688;
            height: 100%;
            width: 0;
            border-radius: 25px;
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: -1;
            transition: 0.5s;
        }
        button:hover span {
            width: 100%;
        }
        button:hover {
            border: none;
        }
        .Voltar {
            height: 100px;
            width: 120px;
            font-size: 20px;
            font-weight: bold;
            padding-left: 40px;
        }
        .Voltar i {
            font-size: 15px;
        }
        .Voltar a {
            color: #009688;
            text-decoration: none;
        }
        .Voltar a:hover {
            text-decoration: underline;
        }

        .con {
            justify-content: center;
            display: flex;
            align-items: center;
            height: 100%;
        }

        .wrapper {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            width: 420px;
            background-color: transparent;
            border: 2px solid rgba(224, 255, 255, 0.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(224, 255, 255, 0.2);
            color: navy;
            padding: 30px 40px;
        }

        .wrapper .remember-forgot {
            display: flex;
            justify-content: space-between;
            font-size: 14.5px;
            margin: 15px 0 15px;
        }
        .remember-forgot label input {
            accent-color: #fff;
            margin-right: 30px;
        }
        .remember-forgot a {
            color: #009688;
            text-decoration: none;
        }
        .remember-forgot a:hover {
            text-decoration: underline;
        }

        .wrapper h1 {
            font-size: 36px;
            text-align: center;
            font-weight: bold;
        }

        .input-box {
            width: 100%;
            height: 100%;
            margin: 30px 0;
            position: relative;
        }
        .input-box input {
            width: 75%;
            height: 75%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(224, 255, 255, 0.2);
            border-radius: 40px;
            font-size: 16px;
            color: #009688;
            padding: 20px 45px 20px 20px;
        }
        .input-box input::placeholder {
            color: navy;
        }
        .input-box i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        .btn {
            width: 200px;
            padding: 15px 0;
            text-align: center;
            margin: 20px 10px;
            border-radius: 25px;
            font-weight: bold;
            border: 2px solid navy;
            background: transparent;
            color: #009688;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            font-weight:bold;
            
        }
        .btn span {
            background: navy;
            height: 100%;
            width: 0;
            border-radius: 25px;
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: -1;
            transition: 0.5s;
            
        }
        .btn:hover span {
            width: 100%;
        }
        .btn:hover {
            border: none;
        }
        .btn a{
            color: #009688;
        }
        .btn a:hover{
            color: #fff;
        }

        .span {
            font-size: 12px;
            color: #009688;
        }
        .wrapper p {
            font-size: 12px;
            color: #009688;
        }
        .wrapper p a {
            text-decoration: none;
            font-weight: bold;
            color: #009688;
        }
        .wrapper p a:hover {
            text-decoration: underline;
            color: navy;
        }
        .wrapper .pass {
            display: flex;
            justify-content: space-between;
        }
        .wrapper .pass a {
            color: #009688;
            font-size: 14.5px;
        }
        .wrapper .pass a:hover {
            text-decoration: underline;
            color: navy;
        }
        .wrapper .register-link {
            font-size: 14.5px;
            text-align: center;
            margin-top: 20px;
        }
        .register-link a {
            color: #009688;
            text-decoration: none;
            font-weight: 600;
        }
        .register-link p a:hover {
            text-decoration: underline;
            color: navy;
        }

        .select-container {
            display: flex;
            justify-content: center;
            position: relative;
            width: 95%;
            height: 60px;
        }
        .select-box {
            appearance: none;
            padding: 0 30px 0 15px;
            width: 100%;
            color: navy;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(224, 255, 255, 0.2);
            border-radius: 40px;
            font-size: 20px;
        }

        .alert {
            padding: 15px;
            font-size: 18px;
            border-radius: 10px;
        }
        .alert svg {
            width: 24px;
            height: 24px;
        }

        /* Custom alert font size */
        .custom-alert {
            font-size: 12px; /* Change this value to the desired font size */
        }
    </style>
</head>
<body>
    <div class="con">
        <div class="wrapper">
            <?php if (!empty($alert)) echo $alert; ?>
            <form action="" method="POST">
                <h1>LOGIN</h1>
                <div class="input-box">
                    <input type="text" name="nome" id="nome" placeholder="Username ou Nome de Empresa" value=""><br>
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box">
                    <input type="password" name="senha" id="senha" placeholder="SENHA" required value=""><br>
                    <i class='bx bxs-lock-alt'></i>
                </div>
                <div class="remember-forgot">
                    <label for=""><input type="checkbox">Lembrar-me.</label>
                    <a href="#">Esqueceu a senha?</a>
                </div>
                <div class="register-link">
                    <p>
                        <button type="submit" name="submit" id="submit" class="btn"> <span></span> LOGIN</button><br>
                        Não tem uma conta?<a href="usuario/cadastrar.php">Cadastrar</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
